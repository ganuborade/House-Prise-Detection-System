import pandas as pd
import joblib

# Load model and features
model = joblib.load("models/model.pkl")
features = joblib.load("models/features.pkl")

# Features you want to ask from user (based on your sample)
feature_questions = {
    "LotArea": "Enter Lot Area (in sq ft): ",
    "YearBuilt": "Enter Year Built (e.g., 2003): ",
    "GrLivArea": "Enter Above ground living area (in sq ft): ",
    "TotRmsAbvGrd": "Enter Total rooms above ground: ",
    "GarageCars": "Enter Number of garage cars: ",
    "1stFlrSF": "Enter 1st floor area (in sq ft): ",
    "2ndFlrSF": "Enter 2nd floor area (in sq ft): ",
    "GarageArea": "Enter Garage area (in sq ft): ",
    "OverallQual": "Enter Overall quality (1-10): ",
    "OverallCond": "Enter Overall condition (1-10): "
}

# Collect inputs from user
user_input = {}
print("Please enter the following details about the house:")

for feature, question in feature_questions.items():
    while True:
        val = input(question)
        try:
            val = float(val)
            user_input[feature] = [val]  # keep as list for DataFrame shape
            break
        except ValueError:
            print("Invalid input! Please enter a numeric value.")

# Create DataFrame from user input
input_df_partial = pd.DataFrame(user_input)

# Reindex columns to match model features, fill missing with 0
input_df = input_df_partial.reindex(columns=features, fill_value=0)

# Predict price
prediction = model.predict(input_df)

# Conversion rate USD to INR (example rate, update if needed)
usd_to_inr = 82

price_inr = prediction[0] * usd_to_inr

print(f"\n🏠 Predicted House Price: ₹{price_inr:,.2f} INR")

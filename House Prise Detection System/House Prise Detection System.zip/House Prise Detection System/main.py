import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
import joblib

import os
os.environ['KAGGLE_CONFIG_DIR'] = os.path.join(os.getcwd(), 'Config')


# Load dataset
data = pd.read_csv("data/train.csv")

# Select numeric features only and drop rows with missing values
data = data.select_dtypes(include=['number']).dropna()
 
# Separate input and target
X = data.drop("SalePrice", axis=1)
y = data["SalePrice"]

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Model training
model = RandomForestRegressor()
model.fit(X_train, y_train)

# Save model
joblib.dump(model, "models/model.pkl")
print("✅ Model trained and saved as models/model.pkl")

features = X.columns.tolist()  # X is your training DataFrame without the target column

import joblib
joblib.dump(features, "models/features.pkl")

